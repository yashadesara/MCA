
<html>
<head>
<script>
	function swapIMG(n, t)
	{
	  var img = document.images[parseInt(n)];
	  var src = img.src;	  
	  img.src = t.src;	  
	  t.src = src;	  
	}
	function mySwap()
	{		
		img1=document.getElementById("i1");
		img2=document.getElementById("i2");
		tscr=img1.src;
		img1.src=img2.src;
		img2.src=tscr;
	}
</script>
</head>
<body>

<img src="a.png" id="i1" value="1" onclick="swapIMG(1, this)" />
<img src="b.png" id="i2" value="2" onclick="swapIMG(0, this)" /> 
<input type="button" value="SWAP" onclick="mySwap();">
</body>
</html>