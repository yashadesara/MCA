<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

    $fn = $_POST['fn'];
    $ln = $_POST['ln'];
    $e = $_POST['e'];
    $msg = $_POST['msg'];

    $sql = "INSERT INTO db (fn, ln, e, msg) VALUES ('$fn', '$ln', '$e','$msg')";
    
    echo "Success";


