<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
    <form method="POST">
        fn : <input type="text" name="fn" id="fn"><br>
        ln : <input type="text" name="ln" id="ln"><br>
        email : <input type="text" name="e" id="e"><br>
        msg : <input type="text" name="msg" id="msg"><br><br>
        <input type="button" value="ADD" id="submit">
    </form>
    <script>
        $(document).ready(function(){
            $("#submit").click(function(){
                var fn = $("#fn").val();
                var ln = $("#ln").val();
                var e = $("#e").val();
                var msg = $("#msg").val();

                $("#fn").css("background-color","#FFF");
                $("#ln").css("background-color","#FFF");
                $("#e").css("background-color","#FFF");
                $("#msg").css("background-color","#FFF");

                if(fn=='')
                {
                    alert("Fill First Name");
                    $("#fn").focus();
                    $("#fn").css("background-color","#F00");
                    return false;
                }
                else if(ln=='')
                {
                    alert("Fill Last Name");
                    $("#ln").focus();
                    $("#ln").css("background-color","#F00");
                    return false;
                }
                else if(e=='')
                {
                    alert("Fill Email");
                    $("#e").focus();
                    $("#e").css("background-color","#F00");
                    return false;
                }
                else if(msg=='')
                {
                    alert("Fill Msg");
                    $("#msg").focus();
                    $("#msg").css("background-color","#F00");
                    return false;
                }
                
                $.ajax({
                    type: "POST",
                    url: "data.php",
                    data: {
                        fn:fn,
                        ln:ln,
                        e:e,
                        msg:msg
                    },
                    cache: false,
                    success: function(data){
                            alert(data);
                    },

                    error: function(xhr, status, error){
                        console.error(xhr);
                    }
                });
            });
        });
    </script>
</body>
</html>

