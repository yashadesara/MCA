<html>
<head>
<script> 
function getData()
{
	var xmlhttp = new XMLHttpRequest();
	xmlhttp.onreadystatechange = function() 
	{
	  if (this.readyState == 4 && this.status == 200) 
	  {
		document.getElementById("res").innerHTML = this.responseText;
	  }
	};
	q="exe.php";
	xmlhttp.open("GET",q, true);
	xmlhttp.send();
}
</script>
</head>
<body> 
<input type="button" value='get data' id='action' onclick="getData();">
<br><br><br>
<div id="res"></div>
</body>
</head>
</html>
