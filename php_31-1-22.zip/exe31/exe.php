<?php

$xml = simplexml_load_file("sample.xml") or die("Error: cannot create object");
echo "<table border='1'>";
echo "<tr><th>id</th>";
echo "<th>title</th>";
echo "<th>price</th></tr>";

foreach($xml->children() as $r)
{
    echo "<tr><td>".$r->id . "</td>";
    echo "<td>".$r->id . "</td>";
    echo "<td>".$r->id . "</td></tr>";
}
echo "</table>";
?>