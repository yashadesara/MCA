<?php
    $conn = new mysqli("localhost","root","","test");    
  /* 
   CREATE TABLE  `product_catalog` (
	  `id` int(100) NOT NULL AUTO_INCREMENT,
	  `name` varchar(100) NOT NULL,
	   qty int(8),
	   price int(8),
	  PRIMARY KEY (`id`)
	);	
	*/
?>
<?php
	$sql="select * from product_catalog";
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='search')
	{
		$sstr=$_REQUEST['q'];
		$sql="select * from product_catalog where name like '%$sstr%'";
	}
	if(isset($_REQUEST['action']) && $_REQUEST['action']=='insert')
	{
		$name1=$_REQUEST['name1'];
		$qty=$_REQUEST['qty'];
		$price=$_REQUEST['price'];
		$sqli="INSERT INTO `product_catalog`(`name`, `qty`, `price`) VALUES('$name1',$qty,$price)";
		$conn->query($sqli);
		echo $sqli;
	}
	 echo $sql;
?>

 
 <div class="container">
    
    <table id="myTable"  >
    <thead>
            <th>ID</th>
            <th>Name</th>
            <th>qty</th>
            <th>price</th>          
            
    </thead>
    <tbody>    
    <?php    
	/*
	$sql="select * from product_catalog";
	if(isset($_REQUEST['sstr']))
	{
		$sstr=$_REQUEST['sstr'];
		$sql="select * from product_catalog where name like '%$sstr%'";
	}
	*/
    $result=$conn->query($sql);
    for($i=0;$i<$result->num_rows;$i++) //row
    {
        echo "<tr>";
            $row = $result->fetch_object();    
            echo "<td>";
                echo $row->id; 
				$id=$row->id;
            echo "</td>";
            echo "<td>";
                echo $row->name; 
            echo "</td>";
            echo "<td>";
                echo $row->qty; 
            echo "</td>";
            echo "<td>";
                echo $row->price; 
            echo "</td>"; 
			 
                
        echo "</tr>"; 
	}
    ?>
    </tbody>
    </table>
    </div>
  
 