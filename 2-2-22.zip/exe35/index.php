<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  
<script>	
		 
		$(document).ready(function() 
		{			
			$("#insert").click(function() {
				var name1 = $("#name1").val(); 
				var qty = $("#qty").val(); 
				var price = $("#price").val();
				if(name1==''||qty==''||price=='') 
				{
					alert("Please fill all fields.");
					return false;
				}
				 
				$.ajax({
					type: "POST",
					url: "e35.php",
					data: {
						action: 'insert',
						name1: name1,
						qty: qty,
						price: price
					},
					cache: false,
					success: function(data) {
						//alert(data);
						document.getElementById("res").innerHTML =data;
					},
					error: function(xhr, status, error) {
						console.error(xhr);
					}
				});
			});
			$("#search").click(function() {
				var search1 = $("#sstr").val(); 
				if(search=='') 
				{
					alert("Please fill all fields.");
					return false;
				}				
			 
				$.ajax({
					type: "POST",
					url: "e35.php",
					data: {
						action: 'search',
						q: search1,
						 
					},
					cache: false,
					success: function(data) {
						//alert(data);
						document.getElementById("res").innerHTML =data;
					},
					error: function(xhr, status, error) {
						console.error(xhr);
					}
				});
			});
		});
	</script>

</head>
<body>
<br>
Search by name : <input type="text" name='sstr' id='sstr'">
<input type="button" value='search' id='search' >
<br>
<br>
Name : <input type="text" name='name1' id='name1'>
Qty : <input type="text" name='qty' id='qty'>
Price :<input type="text" name='price' id='price'>
<input type="button" value='insert' id='insert' >
<br>
<br>
<br>
<div id="res">
</div>

</body>
