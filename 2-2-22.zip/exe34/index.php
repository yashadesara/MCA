<head>
	<script>
		function myfun(str) {
			if (str.length == 0) {
				document.getElementById("res").innerHTML = "";
				return;
			} else {
				var xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
					if (this.readyState == 4 && this.status == 200) 
					{
						document.getElementById("res").innerHTML=this.responseText;
					}
				};
				xmlhttp.open("GET","e34.php?action=search&q=" + str, true);
				xmlhttp.send();
			}
		}

		function insert() {
			var name1 = document.getElementById("name1").value;
			var qty = document.getElementById("qty").value;
			var price = document.getElementById("price").value;
			var action = document.getElementById("action").value;
			var xmlhttp = new XMLHttpRequest();
			xmlhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
					document.getElementById("res").innerHTML = this.responseText;
				}
			};
			q = "e34.php?name1=" + name1 + "&qty=" + qty + "&price=" + price + "&action=" + action;
			xmlhttp.open("GET", q, true);
			xmlhttp.send();
		}
	</script>

</head>
<body>
	<br>
	Search by name : <input type="text" name='sstr' id='sstr' onkeyup="myfun(this.value);">
	<br>
	<br>
	Name : <input type="text" name='name1' id='name1'>
	Qty : <input type="text" name='qty' id='qty'>
	Price :<input type="text" name='price' id='price'>
	<input type="button" value='insert' id='action' onclick="insert();">
	<br>
	<br>
	<br>
	<div id="res">
	</div>
</body>