<?php
include("conn.php");
$data = array();
$query = "SELECT * FROM product_catalog";
$result = $conn->query($query);

while($row = $result->fetch_array())
{
    $id = $row['id'];
    $name = $row['name'];
    $qty = $row['qty'];
    $price = $row['price'];	
    $data[] = array("id" => $id,
                    "name" => $name,
                    "qty" => $qty,
                    "price" => $price);
}
// Encoding array in JSON format
$res=array(
		"data"=>$data,
		"status"=>0,
		"total"=>$result->num_rows,
		"message"=>"no rows available",
	);
echo json_encode($res);