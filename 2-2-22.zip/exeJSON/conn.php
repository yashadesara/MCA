<?php
$conn= new mysqli("localhost", "root", "","test");
if (!$conn)   
    die("Connection failed: " . $conn->connect_error()); 

