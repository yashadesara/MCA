<?php
include("conn.php");
$data = array();

if (!isset($_REQUEST['id'])) 
{
    $res = array(
        "data" => array(),
        "status" => 0,
        "total" => 0,
        "message" => "no rows available",
    );
} 
else 
{
    $sid=$_REQUEST['id'];
$query = "SELECT * FROM product_catalog where id=$sid";
$result = $conn->query($query);

    while ($row = $result->fetch_array()) {
        $id = $row['id'];
        $name = $row['name'];
        $qty = $row['qty'];
        $price = $row['price'];
        $data[] = array(
            "id" => $id,
            "name" => $name,
            "qty" => $qty,
            "price" => $price
        );
            // $row=$res->fetch_assoc();

    }
    // Encoding array in JSON format
    $res = array(
        "data" => $data,
        "status" => 1,
        "total" => $result->num_rows,
        "message" => "Success",
    );
    
}
echo json_encode($res);